#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
new_post.py - 给已搭好的博客加新文章
====================================
用法：
  python new_post.py                          # 交互式问答
  python new_post.py --title "xxx" --category "运维手册"  # 命令行参数

需要 init.py 已经跑过，blog 目录结构已存在。
"""

import argparse
import sys
import subprocess
from datetime import datetime
from pathlib import Path

# ---------- 颜色 ----------
class C:
    PINK = '\033[95m'; BLUE = '\033[94m'; GREEN = '\033[92m'
    YELLOW = '\033[93m'; RED = '\033[91m'; BOLD = '\033[1m'; END = '\033[0m'

    @classmethod
    def enable_windows(cls):
        if sys.platform == 'win32':
            try:
                import ctypes
                ctypes.windll.kernel32.SetConsoleMode(
                    ctypes.windll.kernel32.GetStdHandle(-11), 7
                )
            except Exception: pass


def info(m): print(f"{C.BLUE}ℹ{C.END}  {m}")
def ok(m): print(f"{C.GREEN}✓{C.END}  {m}")
def warn(m): print(f"{C.YELLOW}⚠{C.END}  {m}")
def err(m): print(f"{C.RED}✗{C.END}  {m}")
def ask(prompt, default=''):
    suffix = f" [{C.BOLD}{default}{C.END}]" if default else ''
    raw = input(f"{C.PINK}?{C.END}  {prompt}{suffix}: ").strip()
    return raw or default
def ask_yes_no(prompt, default=True):
    suffix = '[Y/n]' if default else '[y/N]'
    raw = input(f"{C.PINK}?{C.END}  {prompt} {suffix}: ").strip().lower()
    if not raw: return default
    return raw in ('y', 'yes', '是', '好')


# ---------- 模板 ----------
ARTICLE_TEMPLATE = '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{title} - {site_title}</title>
  <meta name="description" content="{description}">
  <meta name="keywords" content="{keywords}">
  <meta name="author" content="{author}">
  <link rel="canonical" href="{url}">
  <link rel="icon" type="image/svg+xml" href="/favicon.svg">

  <meta property="og:type" content="article">
  <meta property="og:title" content="{title} - {site_title}">
  <meta property="og:description" content="{description}">
  <meta property="og:url" content="{url}">
  <meta property="og:image" content="{site_url}/images/og-image.png">
  <meta property="og:site_name" content="{site_title}">
  <meta property="og:locale" content="zh_CN">
  <meta property="article:published_time" content="{date_iso}">
  <meta property="article:author" content="{author}">
  <meta property="article:section" content="{category}">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=PingFang+SC:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/css/article.css">
<style>
pre code .kw {{ color: #ff79c6; font-weight: bold; }}
pre code .fl {{ color: #bd93f9; }}
pre code .nb {{ color: #bd93f9; }}
pre code .s1 {{ color: #50fa7b; }}
pre code .s2 {{ color: #f1fa8c; }}
pre code .c0 {{ color: #6272a4; font-style: italic; }}
pre code .op {{ color: #ff79c6; }}
</style>
</head>
<div class="reading-progress" id="rdProg"></div>
<body>
  <header class="site-header">
    <div class="site-title"><a href="/">{site_title}</a></div>
    <ul class="nav-links">
      <li><a href="/">首页</a></li>
      <li><a href="/about/">关于</a></li>
    </ul>
  </header>
  <main class="container">
    <a href="/" class="back-link">← 返回首页</a>
    <article class="article-card">
      <div class="article-header">
        <h1 class="article-title">{title}</h1>
        <div class="article-meta">
          <span>📅 {date}</span>
          <span>📁 {category}</span>
          {tag_html}
        </div>
      </div>
      <div class="article-content">
<h2>前置条件</h2>
<ul>
  <li>条件 1</li>
  <li>条件 2</li>
</ul>

<h2>步骤 1：xxx</h2>
<pre><code>your-command-here</code></pre>

<h2>验证</h2>
<ul>
  <li>看到 xxx 就说明成功了</li>
</ul>
      </div>
    </article>

    <div class="like-section">
      <button class="like-btn" id="likeBtn">
        <span class="heart">❤️</span>
        <span id="likeText">点赞</span>
        <span id="likeCount">0</span>
      </button>
    </div>

    <div class="comments-section">
      <script src="https://giscus.app/client.js"
        data-repo="andersthorvald/andersthorvald.github.io"
        data-repo-id="R_kgDOSnU2tg"
        data-category="Announcements"
        data-category-id="DIC_kwDOSnU2ts4C92t8"
        data-mapping="pathname"
        data-strict="0"
        data-reactions-enabled="1"
        data-emit-metadata="0"
        data-input-position="top"
        data-theme="preferred_color_scheme"
        data-lang="zh-CN"
        data-loading="lazy"
        crossorigin="anonymous"
        async>
      </script>
    </div>
  </main>

  <button class="scroll-top" id="scrollTop" onclick="scrollToTop()" title="回到顶部" aria-label="回到顶部">↑</button>
  <button class="dark-toggle" onclick="toggleDark()" title="切换深色模式">🌙</button>

  <script>
    function applyDark(d) {{
      document.body.classList[d ? 'add' : 'remove']('dark-mode');
      var b = document.querySelector('.dark-toggle');
      if(b) b.textContent = d ? '☀️' : '🌙';
    }}
    function toggleDark() {{
      var d = !document.body.classList.contains('dark-mode');
      applyDark(d); localStorage.setItem('dark-mode-manual', d);
    }}
    function scrollToTop() {{ window.scrollTo({{ top: 0, behavior: 'smooth' }}); }}
    (function initArticle() {{
      var rdProg = document.getElementById('rdProg');
      function updateProgress() {{
        var docH = document.documentElement.scrollHeight - window.innerHeight;
        if (rdProg) rdProg.style.width = docH > 0 ? (window.scrollY / docH * 100).toFixed(1) + '%' : '0%';
        var st = document.getElementById('scrollTop');
        if (st) {{ if (window.scrollY > 400) st.classList.add('visible'); else st.classList.remove('visible'); }}
      }}
      window.addEventListener('scroll', updateProgress);
      updateProgress();
    }})();
    (function initDark() {{
      var h = new Date().getHours();
      var d = h < 7 || h >= 19;
      var m = localStorage.getItem('dark-mode-manual');
      if (m !== null) d = m === 'true';
      applyDark(d);
    }})();
  </script>
</body>
</html>
'''


def slugify(name):
    """把中文标题转成 URL 友好的 slug"""
    import re
    # 保留中文 + 英文 + 数字 + 横线
    slug = re.sub(r'[^\w\u4e00-\u9fff\-]+', '-', name.lower()).strip('-')
    return slug or 'untitled'


def load_site_yaml(blog_dir):
    """从博客根目录的 site.yaml 读配置（如果存在）"""
    yaml_path = blog_dir / 'site.yaml'
    if not yaml_path.exists():
        return None
    try:
        import yaml
        with open(yaml_path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f) or {}
    except ImportError:
        return None


def main():
    C.enable_windows()

    parser = argparse.ArgumentParser(description='new_post.py - 给博客加新文章')
    parser.add_argument('--blog-dir', default='.', help='博客根目录（默认当前目录）')
    parser.add_argument('--title', help='文章标题')
    parser.add_argument('--category', help='文章分类')
    parser.add_argument('--tags', help='标签，逗号分隔')
    parser.add_argument('--description', help='文章描述（SEO 用）')
    parser.add_argument('--no-commit', action='store_true', help='不自动 git add + commit')
    args = parser.parse_args()

    print(f"{C.PINK}{C.BOLD}")
    print("=" * 50)
    print("   new_post.py  -  博客新增文章")
    print("=" * 50)
    print(f"{C.END}")

    blog_dir = Path(args.blog_dir).resolve()
    if not (blog_dir / 'index.html').exists():
        err(f"在 {blog_dir} 找不到 index.html，看起来不是博客根目录")
        sys.exit(1)

    cfg = load_site_yaml(blog_dir) or {}
    site_title = cfg.get('site', {}).get('title', 'My Wiki')
    author = cfg.get('author', {}).get('name', 'Anonymous')
    site_url = f"https://{cfg.get('deploy', {}).get('github_username', 'example')}.github.io"

    # 收参数
    title = args.title or ask('文章标题', '')
    if not title:
        err('标题不能为空')
        sys.exit(1)

    category = args.category or ask('分类', '默认分类')
    tags_raw = args.tags or ask('标签（逗号分隔）', '')
    description = args.description or ask('描述（一句话）', title)
    tags = [t.strip() for t in tags_raw.split(',') if t.strip()]

    # 路径
    now = datetime.now()
    date_str = now.strftime('%Y-%m-%d')
    date_iso = now.strftime('%Y-%m-%dT%H:%M:%S+08:00')
    slug = slugify(title)
    article_dir = blog_dir / now.strftime('%Y/%m/%d') / slug
    article_path = article_dir / 'index.html'

    # 防覆盖
    if article_path.exists():
        if not ask_yes_no(f'文章已存在 {article_path.name}，要覆盖吗？', False):
            err('已取消')
            sys.exit(0)

    article_dir.mkdir(parents=True, exist_ok=True)

    # 生成 HTML
    tag_html = '\n          '.join(f'<span class="tag">{t}</span>' for t in tags)
    html = ARTICLE_TEMPLATE.format(
        title=title, site_title=site_title, description=description,
        keywords=', '.join(tags), author=author, url=f"{site_url}/{now.strftime('%Y/%m/%d')}/{slug}/",
        site_url=site_url, date_iso=date_iso, date=date_str,
        category=category, tag_html=tag_html,
    )

    article_path.write_text(html, encoding='utf-8')
    ok(f"文章已生成：{article_path.relative_to(blog_dir)}")

    # 可选：自动 commit + push
    if not args.no_commit and ask_yes_no('自动 git add + commit + push？', True):
        try:
            subprocess.run(['git', 'add', '-A'], cwd=blog_dir, check=True)
            subprocess.run(['git', 'commit', '-m', f'post: {title}'], cwd=blog_dir, check=True)
            info('正在 push...')
            subprocess.run(['git', 'push', 'origin', 'HEAD:gh-pages', '--force'],
                          cwd=blog_dir, check=True)
            ok('推送完成！等 1-2 分钟就能看到新文章')
        except subprocess.CalledProcessError as e:
            err(f'Git 操作失败：{e}')
            info('你可以手动执行：')
            info(f'  cd {blog_dir}')
            info(f'  git add -A && git commit -m "post: {title}"')
            info(f'  git push origin HEAD:gh-pages --force')

    print(f"\n{C.GREEN}{C.BOLD}🎉 搞定！{C.END}")
    info(f"文章路径：{article_path}")
    info(f"预览：{site_url}/{now.strftime('%Y/%m/%d')}/{slug}/")
    info('记得去首页 index.html 在合适位置加一张卡片指到这篇文章')


if __name__ == '__main__':
    main()
