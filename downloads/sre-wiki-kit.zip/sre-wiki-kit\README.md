# SRE Wiki Kit

> **零基础一键搭建个人博客** — 给同班同学看的完整教程

这是一个 Python 脚本 + 模板项目，让你的同班同学**5 分钟**拥有自己的 GitHub Pages 个人博客。
代码、样式、SEO 配置、Giscus 评论、Git 推送全自动搞定。

---

## 目录

- [这是什么](#这是什么)
- [5 分钟快速开始](#5-分钟快速开始)
- [两种配置方式](#两种配置方式)
- [脚本到底干了啥](#脚本到底干了啥)
- [常见问题](#常见问题)
- [如何加新文章](#如何加新文章)
- [进阶：自定义主题](#进阶自定义主题)
- [Docker 版（不用装 Python）](#docker-版不用装-python)
- [直接拉取预构建镜像](#直接拉取预构建镜像)
- [开发者：自动化发布](#开发者自动化发布)

---

## 这是什么

博主写了个 [SRE Wiki 个人博客](https://andersthorvald.github.io)，现在把这个博客
**拆成模板**，配上一个 Python 脚本，让同班同学不用懂前端、不用懂部署，
跑一行命令就能有自己的博客。

**功能清单：**
- ✅ 一键生成完整静态博客（HTML/CSS/SEO/404）
- ✅ 玻璃质感卡片 + 粉色渐变 + 深色模式（自动切换 19:00-07:00）
- ✅ 阅读进度条 + 代码语法高亮 + 点赞 + Giscus 评论
- ✅ 自动 `git init` + 推送到 `gh-pages` 分支
- ✅ 响应式（手机/平板/电脑都好看）

**同学需要准备的：**
1. Python 3.7+（装 Python 的时候勾上 "Add to PATH"）
2. Git（[下载](https://git-scm.com/)）
3. 一个 GitHub 账号（没有就去 [注册](https://github.com/signup)）
4. 一双手 + 5 分钟

---

## 5 分钟快速开始

### 第 1 步：准备 GitHub 仓库

登录 GitHub → 右上角 `+` → **New repository** →
名字填 `<你的用户名>.github.io`（**必须**这样填，GitHub Pages 个人主页规则）→
选 **Public** → 点 **Create repository**。

> 比如你的用户名是 `zhangsan`，仓库名就是 `zhangsan.github.io`。
> 这步只是创建空仓库，**不用**勾选 Add README / .gitignore。

### 第 2 步：下载这个项目

打开终端（Windows 用 PowerShell，Mac/Linux 用 Terminal），进入你想放代码的目录：

```bash
# 进入工作目录
cd D:\code        # Windows 示例
# cd ~/code       # Mac/Linux 示例

# 把项目下载下来（先看老师/同学分享给你的是哪个地址）
# 如果是从 GitHub clone：
git clone https://github.com/<分享者用户名>/sre-wiki-kit.git
cd sre-wiki-kit

# 如果是直接拿到的压缩包：解压后 cd 进去就行
```

### 第 3 步：装依赖

```bash
pip install pyyaml
```

> 如果 `pip` 提示找不到，试试 `python -m pip install pyyaml` 或 `pip3 install pyyaml`。

### 第 4 步：跑脚本

**方式 A：交互式问答（推荐新手）**

```bash
python init.py
```

脚本会一题一题问你，照着填就行。最后会让你确认，回车就开始生成 + 推送。

**方式 B：改配置文件（推荐想仔细调的同学）**

```bash
# 1. 复制示例配置
cp examples/site.yaml site.yaml

# 2. 用记事本/VSCode 打开 site.yaml，改成你自己的信息
#    （每行都有注释告诉你干嘛的）

# 3. 跑脚本
python init.py --config site.yaml
```

### 第 5 步：去 GitHub 开 Pages

1. 打开你刚才创建的仓库（比如 `https://github.com/zhangsan/zhangsan.github.io`）
2. 点 **Settings** → 左边栏 **Pages**
3. **Source** 选 **Deploy from a branch**
4. **Branch** 选 `gh-pages`，目录 `/ (root)`
5. 点 **Save**

等 1-2 分钟，访问 `https://zhangsan.github.io` 就能看到你的博客了 🎉

---

## 两种配置方式

### 交互式问答模式

```bash
python init.py
```

脚本会按顺序问：

```
? 网站标题 [My Wiki]: 我的技术笔记
? 副标题（一句话描述） [记录与分享]: 边学边记
? 你的名字 / 昵称 [Your Name]: 张三
...
? GitHub 用户名（留空稍后再配）: zhangsan
? 仓库名（个人主页用 <username>.github.io）: zhangsan.github.io
? 生成后立即推送到 GitHub？ [Y/n]: y
```

每个问题后面 `[xxx]` 是默认值，直接回车就用默认。

### 配置文件模式

编辑 `site.yaml`：

```yaml
site:
  title: "我的技术笔记"        # 改这里！
  subtitle: "边学边记"        # 改这里！
  # ...

author:
  name: "张三"                # 改这里！
  # ...
```

改完跑：

```bash
python init.py --config site.yaml
```

两种方式效果一样，配置文件适合「想批量生成 / 改一次以后都能用」的同学。

---

## 脚本到底干了啥

不感兴趣可以跳过这节，但**踩坑的时候回来看一眼**会有帮助。

```
python init.py
    │
    ├─ 1. 加载配置（YAML / 交互问答）
    │
    ├─ 2. 渲染模板
    │     ├─ templates/pages/index.html   →  index.html
    │     ├─ templates/pages/about.html   →  about/index.html
    │     ├─ templates/pages/article.html  →  （作为新文章模板）
    │     ├─ templates/pages/404.html     →  404.html
    │     ├─ templates/css/article.css    →  css/article.css
    │     └─ templates/favicon.svg        →  favicon.svg
    │
    ├─ 3. 生成 SEO 文件
    │     ├─ sitemap.xml      （让 Google/Bing 找到你）
    │     ├─ robots.txt       （搜索引擎规则）
    │     └─ .nojekyll        （告诉 GitHub Pages 不要走 Jekyll）
    │
    └─ 4. Git 操作
          ├─ git init
          ├─ git add -A
          ├─ git commit -m "init: ..."
          └─ git push origin HEAD:gh-pages --force
```

**整个流程不到 1 分钟**，比手写 HTML 再手动配 Pages 快 100 倍。

---

## 常见问题

### Q1: 推送失败，提示 "Permission denied"

**原因**：GitHub 早就不能用密码推送了，必须用 SSH 或 Personal Access Token。

**解决**：

1. 打开 https://github.com/settings/tokens
2. 点 **Generate new token (classic)**
3. Note 随便填，Expiration 选 `No expiration`
4. 勾选 `repo` 权限
5. 点 **Generate token**，**复制**这个 token（只显示一次！）
6. 推送时第一次会弹窗要用户名密码：
   - 用户名：你的 GitHub 用户名
   - 密码：**粘贴刚才的 token**（不是登录密码）

### Q2: 网站打开是 404

**原因**：Pages 没启用或选错分支。

**解决**：
1. 仓库 → **Settings** → **Pages**
2. **Source** 必须是 `gh-pages` 分支
3. 等 1-2 分钟（首次部署慢一点）
4. 刷新浏览器

### Q3: 中文显示乱码

**原因**：你的文本编辑器保存时用了 GBK 编码。

**解决**：用 VSCode / Notepad++ 打开，`Ctrl+S` 重新保存，选 **UTF-8 编码**。

### Q4: 想换主题颜色

编辑 `site.yaml`：

```yaml
theme:
  primary: "#3498db"     # 改成蓝色
  secondary: "#85c1e9"
  accent: "#d6eaf8"
```

> ⚠️ 颜色变量是在 CSS 里写死的，目前改 `site.yaml` 不会自动同步到样式。
> 完整版主题切换功能在 [TODO 列表](#进阶自定义主题) 里。

### Q5: 想加自己的头像

把 `my-photo.jpg` 放到 `images/` 文件夹，然后在 `templates/pages/index.html` 里改：

```html
<div class="article-icon">
  <img src="/images/my-photo.jpg" alt="我">
</div>
```

---

## 如何加新文章

### 方式 A：直接复制首页的卡片（最快）

1. 打开 `index.html`
2. 找到 `<div class="article-grid">` 块
3. 复制一段 `<a href="#" class="article-card">...</a>` 整段代码
4. 改 `href` 到新文章路径，修改标题/描述/标签

### 方式 B：写完整文章

1. 新建目录：`2026/06/08/我的新文章/`
2. 在里面创建 `index.html`
3. 内容直接写 HTML：

```html
<h2>前置条件</h2>
<ul>
  <li>需要装好 Python 3.7+</li>
  <li>需要注册 GitHub 账号</li>
</ul>

<h2>步骤 1：xxx</h2>
<pre><code>pip install xxx</code></pre>

<h2>验证</h2>
<ul>
  <li>看到 xxx 就说明成功了</li>
</ul>
```

> 直接 HTML，不用 Markdown。代码块语法高亮已经内置在 CSS 里。

---

## 进阶：自定义主题

[ ] 多主题切换（粉色 / 蓝色 / 绿色）
[ ] 暗色模式色板可配
[ ] 集成 Cloudflare Pages / Vercel 部署
[ ] 文章列表自动扫描生成
[ ] 支持 Markdown 写文章

---

## Docker 版（不用装 Python）

电脑没装 Python？没问题，项目自带 Dockerfile + docker-compose.yml。

### 前提

- 安装 [Docker Desktop](https://www.docker.com/products/docker-desktop/)（Win/Mac/Linux 都有）
- 不用装 Python，不用装 PyYAML

### 用法

```bash
# 1. 进入解压后的项目目录
cd sre-wiki-kit

# 2. 构建镜像（首次需要 1-2 分钟）
docker build -t sre-wiki-kit .

# 3. 跑起来（交互式问答）
docker run -it --rm -v ${PWD}:/wiki sre-wiki-kit

# 或：用 docker-compose（更简单）
docker compose run --rm sre-wiki-kit
```

**用配置文件方式：**

```bash
# 准备好 site.yaml 后
docker run -it --rm -v ${PWD}:/wiki sre-wiki-kit --config /wiki/site.yaml
```

### Windows PowerShell 用户注意

`${PWD}` 在 PowerShell 里要写成 `${PWD}` 或 `$(pwd)`，如果不行就用绝对路径：

```powershell
docker run -it --rm -v C:\Users\YourName\Desktop\sre-wiki-kit:/wiki sre-wiki-kit
```

### 镜像多大

基于 `python:3.11-slim`，**压缩后约 50MB**，拉取一次以后秒开。

---

## 直接拉取预构建镜像

如果项目托管在 GitHub，已经用 GitHub Actions 自动构建并发布到 GHCR（GitHub Container Registry），
同学根本不用本地 build，直接拉就行：

```bash
# 拉最新版本（替换用户名）
docker pull ghcr.io/<用户名>/sre-wiki-kit:latest

# 跑起来
docker run -it --rm -v ${PWD}:/wiki ghcr.io/<用户名>/sre-wiki-kit:latest
```

支持多架构：
- `linux/amd64`：Intel/AMD 芯片电脑
- `linux/arm64`：Apple Silicon（M1/M2/M3）Mac

---

## 开发者：自动化发布

项目自带两个 GitHub Actions 工作流，在 `.github/workflows/` 目录。

### Docker 镜像发布（`docker-publish.yml`）

**触发时机**：
- 推送 `main` 分支 → 发布 `:latest` 镜像
- 推送 `v*` 标签 → 发布带版本号的镜像（`v1.0.0`, `v1.0`, `v1`）
- Actions 页面手动触发

**多架构支持**：同时构建 `linux/amd64` 和 `linux/arm64`。

**验证**：自动 pull 镜像跑 `--help` 冒烟测试。

### Release 发布（`release.yml`）

**触发时机**：推送 `v*` 标签（如 `v1.0.0`）。

**自动做的事**：
1. 打包源码成 zip（自动排除 `.git`、`.github`、测试产物）
2. 上传为 GitHub Actions artifact
3. 创建 GitHub Release，附带 zip 下载

**用法**：

```bash
# 本地打 tag 并推送，触发自动 release
git tag v1.0.0
git push origin v1.0.0

# GitHub 上会自动出现：
#   https://github.com/<用户名>/sre-wiki-kit/releases/tag/v1.0.0
# 包含 sre-wiki-kit.zip 下载
```

### 第一次配置

把项目推到 GitHub 后，需要：

1. **仓库 Settings → Actions → General → Workflow permissions**
   选 **Read and write permissions**（让 Actions 能推 GHCR）

2. **仓库 Settings → Packages → 公开**
   默认是 Private，改成 Public，同学才能拉

3. （可选）推送第一个 tag 试一下：
   ```bash
   git tag v0.1.0
   git push origin v0.1.0
   ```

4. 镜像地址：`ghcr.io/<你的-github-用户名>/sre-wiki-kit`

---

## 致谢

模板基于 [SRE Wiki by Thorvald](https://andersthorvald.github.io) 项目。
CSS 用了 Glassmorphism + 渐变 + 暗色模式常见套路。
所有外部资源（Google Fonts、Giscus）都用了 CDN。

有问题直接问分享这个项目给你的同学，或者去 GitHub 提 Issue。
