#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SRE Wiki Kit - 一键搭建个人博客
================================
用法：
  python init.py                     # 交互式问答模式
  python init.py --config site.yaml  # 用配置文件
  python init.py --dry-run           # 只生成文件，不推送到 GitHub

环境要求：Python 3.7+（标准库即可，不需要装额外包）
"""

import argparse
import os
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

# ---------- 颜色辅助 ----------
class C:
    """终端彩色输出（Windows 10+ / Linux / Mac 都支持）"""
    PINK = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    END = '\033[0m'

    @classmethod
    def enable_windows(cls):
        """Windows 下启用 ANSI 颜色支持"""
        if sys.platform == 'win32':
            try:
                import ctypes
                kernel32 = ctypes.windll.kernel32
                kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
            except Exception:
                pass


def info(msg): print(f"{C.BLUE}ℹ{C.END}  {msg}")
def ok(msg): print(f"{C.GREEN}✓{C.END}  {msg}")
def warn(msg): print(f"{C.YELLOW}⚠{C.END}  {msg}")
def err(msg): print(f"{C.RED}✗{C.END}  {msg}")
def step(msg): print(f"\n{C.PINK}{C.BOLD}▶ {msg}{C.END}")


# ---------- 默认配置 ----------
DEFAULT_CONFIG = {
    'site': {
        'title': 'My Wiki',
        'subtitle': '记录与分享',
        'description': '一个个人知识库，记录学习与实践。',
        'keywords': '笔记, 博客, 个人 Wiki',
    },
    'author': {
        'name': 'Your Name',
        'role': 'Developer / Engineer',
        'bio': '记录学习、分享心得。',
        'interests': ['技术', '写作', '分享'],
    },
    'deploy': {
        'github_username': '',
        'repo_name': '',
        'branch': 'gh-pages',
        'auto_push': True,
    },
    'social': {},
    'giscus': {
        'enabled': True,
        'repo': '',
        'repo_id': '',
        'category': 'Announcements',
        'category_id': '',
    },
    'theme': {
        'primary': '#ff9a9e',
        'secondary': '#fad0c4',
        'accent': '#fecfef',
        'dark_bg': '#12122a',
    },
}

# 工具脚本所在目录
SCRIPT_DIR = Path(__file__).parent.resolve()
TEMPLATE_DIR = SCRIPT_DIR / 'templates'


# ---------- 配置加载 ----------
def load_yaml_config(path):
    """极简 YAML 解析（不依赖 PyYAML，只支持配置文件里的扁平/嵌套结构）"""
    try:
        import yaml
        with open(path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f) or {}
    except ImportError:
        warn("没装 PyYAML，用内置解析器（够用）")
        return _simple_yaml_parse(path)


def _simple_yaml_parse(path):
    """内置简化版 YAML 解析：只支持本项目 site.yaml 用到的语法"""
    config = {}
    stack = [(config, -1)]
    current_section = None

    with open(path, 'r', encoding='utf-8') as f:
        for raw_line in f:
            line = raw_line.rstrip()
            stripped = line.lstrip()
            if not stripped or stripped.startswith('#'):
                continue
            indent = len(line) - len(stripped)
            if stripped.startswith('- '):
                # 列表项（只支持顶层列表）
                value = stripped[2:].strip().strip('"').strip("'")
                if current_section and current_section in config:
                    if not isinstance(config[current_section], list):
                        config[current_section] = []
                    config[current_section].append(value)
                continue
            if ':' in stripped:
                key, _, value = stripped.partition(':')
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                if indent == 0:
                    config[key] = {} if not value else value
                    current_section = key if not value else None
                elif indent == 2:
                    if isinstance(config.get(list(config.keys())[-1] if config else ''), dict):
                        top_key = list(config.keys())[-1]
                        config[top_key][key] = value
                        current_section = top_key
    return config


def deep_merge(base, override):
    """深度合并字典：override 覆盖 base"""
    result = dict(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(result.get(k), dict):
            result[k] = deep_merge(result[k], v)
        else:
            result[k] = v
    return result


# ---------- 交互问答 ----------
def ask(prompt, default=''):
    """带默认值的输入"""
    if default:
        raw = input(f"{C.PINK}?{C.END}  {prompt} [{C.BOLD}{default}{C.END}]: ").strip()
    else:
        raw = input(f"{C.PINK}?{C.END}  {prompt}: ").strip()
    return raw or default


def ask_yes_no(prompt, default=True):
    """是否问题"""
    suffix = '[Y/n]' if default else '[y/N]'
    raw = input(f"{C.PINK}?{C.END}  {prompt} {suffix}: ").strip().lower()
    if not raw:
        return default
    return raw in ('y', 'yes', '是', '好')


def interactive_config():
    """交互式收集配置"""
    step("配置你的博客（直接回车用默认值）")

    cfg = {}
    cfg['site'] = {
        'title': ask('网站标题', DEFAULT_CONFIG['site']['title']),
        'subtitle': ask('副标题（一句话描述）', DEFAULT_CONFIG['site']['subtitle']),
        'description': ask('网站描述（SEO 用）', DEFAULT_CONFIG['site']['description']),
        'keywords': ask('关键词（逗号分隔）', DEFAULT_CONFIG['site']['keywords']),
    }
    cfg['author'] = {
        'name': ask('你的名字 / 昵称', DEFAULT_CONFIG['author']['name']),
        'role': ask('你的角色', DEFAULT_CONFIG['author']['role']),
        'bio': ask('一句话自我介绍', DEFAULT_CONFIG['author']['bio']),
    }
    interests_raw = ask('兴趣标签（逗号分隔）', ', '.join(DEFAULT_CONFIG['author']['interests']))
    cfg['author']['interests'] = [x.strip() for x in interests_raw.split(',') if x.strip()]

    cfg['deploy'] = {
        'github_username': ask('GitHub 用户名（留空稍后再配）', ''),
        'repo_name': ask('仓库名（个人主页用 <username>.github.io）', ''),
        'branch': ask('部署分支', 'gh-pages'),
        'auto_push': ask_yes_no('生成后立即推送到 GitHub？', True),
    }

    cfg['social'] = {}
    if ask_yes_no('要配置联系方式吗？', False):
        email = ask('邮箱', '')
        if email: cfg['social']['email'] = email
        gh = ask('GitHub 用户名', '')
        if gh: cfg['social']['github'] = gh

    cfg['giscus'] = {'enabled': ask_yes_no('启用 Giscus 评论？', True)}
    return cfg


# ---------- 文件生成 ----------
def render_template(template_str, variables):
    """简单的 {{VAR}} 占位符替换"""
    result = template_str
    for key, value in variables.items():
        result = result.replace('{{' + key + '}}', str(value))
    return result


def load_template(name):
    with open(TEMPLATE_DIR / 'pages' / name, 'r', encoding='utf-8') as f:
        return f.read()


def make_social_links(social):
    """生成社交链接 HTML"""
    if not social:
        return '<span style="color:#999">暂无</span>'
    icons = {
        'email': ('邮箱', 'mailto:{v}'),
        'github': ('GitHub', 'https://github.com/{v}'),
        'twitter': ('Twitter', 'https://twitter.com/{v}'),
        'bilibili': ('B站', 'https://space.bilibili.com/{v}'),
        'youtube': ('YouTube', 'https://youtube.com/@{v}'),
        'website': ('个人站', '{v}'),
    }
    parts = []
    for k, url_tpl in icons.items():
        if social.get(k):
            url = url_tpl.format(v=social[k])
            parts.append(f'<a href="{url}" target="_blank" class="social-link">{icons[k][0]}</a>')
    return '\n'.join(parts) if parts else '<span style="color:#999">暂无</span>'


def make_footer_links(social):
    if social.get('github'):
        return f'<a href="https://github.com/{social["github"]}" target="_blank">GitHub</a>'
    return ''


def make_interest_tags(interests):
    return '\n'.join(f'<span class="tag">{x}</span>' for x in (interests or []))


def build_giscus(cfg):
    """生成 Giscus 评论 HTML"""
    if not cfg.get('giscus', {}).get('enabled', True):
        return '<p style="text-align:center;color:#999">评论已关闭</p>'
    repo = cfg['giscus'].get('repo') or cfg['deploy'].get('repo_name', '')
    repo_id = cfg['giscus'].get('repo_id', 'R_kgDOSnU2tg')  # 默认示例 ID
    cat_id = cfg['giscus'].get('category_id', 'DIC_kwDOSnU2ts4C92t8')
    return f'''<script src="https://giscus.app/client.js"
        data-repo="{repo}"
        data-repo-id="{repo_id}"
        data-category="{cfg['giscus'].get('category', 'Announcements')}"
        data-category-id="{cat_id}"
        data-mapping="pathname"
        data-strict="0"
        data-reactions-enabled="1"
        data-emit-metadata="0"
        data-input-position="top"
        data-theme="preferred_color_scheme"
        data-lang="zh-CN"
        data-loading="lazy"
        crossorigin="anonymous"
        async>
      </script>'''


def build_variables(cfg, article_count=3, category_count=3, tag_count=10):
    """构造模板变量字典"""
    site_url = f"https://{cfg['deploy']['github_username']}.github.io/{cfg['deploy']['repo_name']}" if cfg['deploy']['github_username'] else "https://example.com"
    if cfg['deploy']['repo_name'].endswith('.github.io'):
        site_url = f"https://{cfg['deploy']['github_username']}.github.io"

    return {
        'SITE_TITLE': cfg['site']['title'],
        'SITE_DESCRIPTION': cfg['site']['description'],
        'SITE_KEYWORDS': cfg['site']['keywords'],
        'SITE_URL': site_url,
        'AUTHOR_NAME': cfg['author']['name'],
        'AUTHOR_ROLE': cfg['author']['role'],
        'AUTHOR_BIO': cfg['author']['bio'],
        'HERO_TITLE': cfg['site'].get('title', 'My Wiki'),
        'HERO_SUBTITLE': cfg['site'].get('subtitle', ''),
        'AVATAR_INITIAL': cfg['author']['name'][0].upper() if cfg['author'].get('name') else 'M',
        'INTEREST_TAGS': make_interest_tags(cfg['author'].get('interests', [])),
        'SOCIAL_LINKS': make_social_links(cfg.get('social', {})),
        'FOOTER_LINKS': make_footer_links(cfg.get('social', {})),
        'BUILD_DATE': datetime.now().strftime('%Y-%m-%d'),
        'ARTICLE_COUNT': article_count,
        'CATEGORY_COUNT': category_count,
        'TAG_COUNT': tag_count,
        'ARTICLE_CARDS': build_article_cards(),
        'GISCUS_COMMENTS': build_giscus(cfg),
    }


def build_article_cards():
    """示例文章卡片"""
    samples = [
        ('🚀', '如何写出好文档', '用最少的术语把概念讲清楚，每个命令都给可执行示例。', ['docs', 'writing']),
        ('🛠️', 'Linux 常用命令速查', '日常运维 80% 用到的命令，覆盖文件、网络、进程管理。', ['linux', 'cheatsheet']),
        ('📦', 'Docker 入门指南', '从 docker run 到 docker compose 的完整路径。', ['docker', '入门']),
    ]
    parts = []
    for icon, title, desc, tags in samples:
        tag_html = ''.join(f'<span class="tag-pill">{t}</span>' for t in tags)
        parts.append(f'''<a href="#" class="article-card">
        <div class="article-card-top">
          <div class="article-icon"><span style="font-size:1.5rem">{icon}</span></div>
          <div class="article-meta-row"><div class="article-title">{title}</div></div>
        </div>
        <p class="article-desc">{desc}</p>
        <div class="article-footer">
          <div class="article-tags">{tag_html}</div>
          <div class="article-arrow">→</div>
        </div>
      </a>''')
    return '\n'.join(parts)


# ---------- 文件生成主流程 ----------
def generate_site(cfg, output_dir, dry_run=False):
    """根据配置生成整个网站"""
    step(f"生成网站到：{output_dir}")

    output_dir = Path(output_dir).resolve()
    if output_dir.exists() and not dry_run:
        if not ask_yes_no(f"目录 {output_dir.name} 已存在，要清空重建吗？", True):
            err("已取消")
            sys.exit(1)
        shutil.rmtree(output_dir)

    output_dir.mkdir(parents=True, exist_ok=True)

    variables = build_variables(cfg)

    # 首页
    info("生成 index.html ...")
    (output_dir / 'index.html').write_text(
        render_template(load_template('index.html'), variables),
        encoding='utf-8'
    )

    # about
    info("生成 about/index.html ...")
    (output_dir / 'about').mkdir(exist_ok=True)
    (output_dir / 'about' / 'index.html').write_text(
        render_template(load_template('about.html'), variables),
        encoding='utf-8'
    )

    # 404
    info("生成 404.html ...")
    (output_dir / '404.html').write_text(
        render_template(load_template('404.html'), variables),
        encoding='utf-8'
    )

    # CSS
    info("复制 css/ ...")
    shutil.copytree(TEMPLATE_DIR / 'css', output_dir / 'css')

    # favicon
    info("复制 favicon.svg ...")
    shutil.copy(TEMPLATE_DIR / 'favicon.svg', output_dir / 'favicon.svg')

    # 占位 images 目录
    (output_dir / 'images').mkdir(exist_ok=True)
    (output_dir / 'images' / 'README.md').write_text(
        '# 把 og-image.png 放这里（1200x630，PNG）\n', encoding='utf-8'
    )

    # sitemap
    info("生成 sitemap.xml ...")
    site_url = variables['SITE_URL']
    sitemap = f'''<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>{site_url}/</loc><lastmod>{variables['BUILD_DATE']}</lastmod><priority>1.0</priority></url>
  <url><loc>{site_url}/about/</loc><lastmod>{variables['BUILD_DATE']}</lastmod><priority>0.8</priority></url>
</urlset>
'''
    (output_dir / 'sitemap.xml').write_text(sitemap, encoding='utf-8')

    # robots
    (output_dir / 'robots.txt').write_text(
        f'User-agent: *\nAllow: /\nSitemap: {site_url}/sitemap.xml\n', encoding='utf-8'
    )

    # .nojekyll（让 GitHub Pages 不走 Jekyll 渲染）
    (output_dir / '.nojekyll').write_text('', encoding='utf-8')

    ok(f"网站生成完成 → {output_dir}")
    return output_dir


# ---------- Git 操作 ----------
def run(cmd, cwd=None, check=True, capture=False):
    """运行 shell 命令"""
    if isinstance(cmd, str):
        cmd = cmd.split() if ' ' in cmd and not cmd.startswith('"') else [cmd]
    result = subprocess.run(
        cmd, cwd=cwd, check=check, capture_output=capture, text=True,
        shell=isinstance(cmd, str)
    )
    return result


def git_init_and_push(site_dir, cfg, dry_run=False):
    """初始化 Git 仓库并推送到 gh-pages"""
    step("Git 操作")

    if not cfg['deploy'].get('github_username') or not cfg['deploy'].get('repo_name'):
        warn("没配 GitHub 用户名/仓库，跳过推送")
        info("你可以稍后手动执行：")
        info(f"  cd {site_dir}")
        info(f"  git init && git add -A && git commit -m 'init'")
        info(f"  git remote add origin https://github.com/{cfg['deploy']['github_username'] or '<user>'}/<repo>.git")
        info(f"  git push origin HEAD:{cfg['deploy']['branch']} --force")
        return

    gh_user = cfg['deploy']['github_username']
    repo = cfg['deploy']['repo_name']
    branch = cfg['deploy']['branch']
    remote = f"https://github.com/{gh_user}/{repo}.git"

    if not cfg['deploy'].get('auto_push', True):
        warn("auto_push=false，跳过推送")
        return

    if dry_run:
        info("[dry-run] 假装推送了一下")
        return

    # 检查 git
    if not shutil.which('git'):
        err("找不到 git，请先安装 Git")
        sys.exit(1)

    try:
        info("git init ...")
        run(['git', 'init'], cwd=site_dir, check=True)
        run(['git', 'checkout', '-b', branch], cwd=site_dir, check=False)
        run(['git', 'add', '-A'], cwd=site_dir, check=True)
        run(['git', 'commit', '-m', 'init: bootstrap personal wiki'], cwd=site_dir, check=True)
        info("添加 remote ...")
        run(['git', 'remote', 'remove', 'origin'], cwd=site_dir, check=False)
        run(['git', 'remote', 'add', 'origin', remote], cwd=site_dir, check=True)
        info(f"推送到 {branch} ...")
        run(['git', 'push', 'origin', f'HEAD:{branch}', '--force'], cwd=site_dir, check=True)
        ok(f"推送完成 → https://github.com/{gh_user}/{repo}")
        ok(f"网站地址：https://{gh_user}.github.io" + ("" if repo.endswith('.github.io') else f"/{repo}"))
    except subprocess.CalledProcessError as e:
        err(f"Git 操作失败：{e}")
        info("你可以手动执行推送命令（脚本里都给你打印了）")
        sys.exit(1)


# ---------- 入口 ----------
def main():
    C.enable_windows()

    parser = argparse.ArgumentParser(
        description='SRE Wiki Kit - 一键搭建个人博客',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='示例：\n'
               '  python init.py                    # 交互式问答\n'
               '  python init.py --config site.yaml  # 用配置文件\n'
               '  python init.py --dry-run           # 只生成，不推送\n'
    )
    parser.add_argument('--config', '-c', help='YAML 配置文件路径')
    parser.add_argument('--output', '-o', default='./my-wiki', help='输出目录（默认 ./my-wiki）')
    parser.add_argument('--dry-run', action='store_true', help='只生成文件，不推送')
    args = parser.parse_args()

    print(f"{C.PINK}{C.BOLD}")
    print("=" * 50)
    print("   SRE Wiki Kit  -  一键搭建个人博客")
    print("=" * 50)
    print(f"{C.END}")

    # 加载配置
    if args.config:
        info(f"加载配置：{args.config}")
        user_cfg = load_yaml_config(args.config)
    else:
        user_cfg = interactive_config()

    cfg = deep_merge(DEFAULT_CONFIG, user_cfg)

    # 确认
    step("确认配置")
    print(f"  网站标题：{C.BOLD}{cfg['site']['title']}{C.END}")
    print(f"  作者：{C.BOLD}{cfg['author']['name']}{C.END}")
    print(f"  GitHub：{C.BOLD}{cfg['deploy']['github_username'] or '(未设置)'}{C.END}")
    print(f"  输出目录：{C.BOLD}{args.output}{C.END}")
    print(f"  推送到 GitHub：{C.BOLD}{'是' if cfg['deploy'].get('auto_push') and cfg['deploy'].get('github_username') else '否'}{C.END}")

    if not args.dry_run and cfg['deploy'].get('github_username'):
        if not ask_yes_no('\n开始生成？', True):
            err("已取消")
            sys.exit(0)

    # 生成
    site_dir = generate_site(cfg, args.output, dry_run=args.dry_run)

    # Git 推送
    if not args.dry_run:
        git_init_and_push(site_dir, cfg, dry_run=args.dry_run)

    # 下一步
    step("下一步")
    info("1. 去 GitHub 仓库 Settings → Pages，确认 Source 选的是 gh-pages 分支")
    info("2. 等 1-2 分钟访问你的网站")
    info(f"3. 想加新文章？复制 {site_dir}/index.html 里的卡片，照着改就行")
    print(f"\n{C.GREEN}{C.BOLD}🎉 搞定了！{C.END}\n")


if __name__ == '__main__':
    main()
